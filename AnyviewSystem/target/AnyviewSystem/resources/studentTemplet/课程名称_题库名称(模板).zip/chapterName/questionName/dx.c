﻿char ss[8][25];
int k;
printf(char *s){
  strcpy(ss[k++],s);
}

#include "CP01EX025.c"
#include "stds.c"

void anyviewmain() {
  int i;
  k=0;
  main_ans();
  for(i=0; i<k; i++) {
    ans_printf("%s",ss[i]);
    strcpy(ss[i],"                        ");
  }
  k=0;
  main();
  for(i=0; i<k; i++) 
    exe_printf("%s",ss[i]);

  check_exec_printf(1);
}
